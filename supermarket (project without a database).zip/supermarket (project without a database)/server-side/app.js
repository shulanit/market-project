var createError = require('http-errors');
var express = require('express');
var path = require('path');
const bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var cors = require('cors');
var passport = require('passport');
var mongoose = require('mongoose');
var session = require('express-session');
const redis = require('redis');
var http = require('http');
//var LocalStrategy = require('passport-local').Strategy;


var orderRouter = require('./routes/order');
var productRouter = require('./routes/product');
var usersRouter = require('./routes/users');
var loginRouter = require('./routes/login');
var registerRouter = require('./routes/registration');
var shopRouter = require('./routes/shopping');

var app = express();

//app.use(passport.initialize());
//app.use(passport.session());

app.use(cors());
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

// Add headers
app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', true);

  // Pass to next layer of middleware
  next();
});

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser('1234567890QWERTY'));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/order', orderRouter);
app.use('/product', productRouter);
app.use('/users', usersRouter);
app.use('/login', loginRouter);
app.use('/registration', registerRouter);
app.use('/shopping', shopRouter);


var User = require('./models/User');
mongoose.connect('mongodb://localhost:27017/myMarket', {useNewUrlParser: true}, function(){
  console.log('connected');
});
// passport.serializeUser(function(user, done) {
//   done(null, user.id);
//   console.log(user);
// });

// passport.deserializeUser(function(id, done) {
//   User.findById(id, function(err, user) {
//     done(err, user);
//   });
// });
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
