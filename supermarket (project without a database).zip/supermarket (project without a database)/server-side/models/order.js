var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');


var orderSchema = new mongoose.Schema({
    order_id:Number,
    cart_id:String,
    user_id:String,
    final_price:Number,
    order_to_city:String,
    order_to_street:String,
    date_to_send:Date,//משלוח
    date_order:Date,//תאריך ביצוע ההזמנה
    card:Number,
    list:Array
});

var Order = mongoose.model('Order', orderSchema, "orders");
module.exports = Order;
