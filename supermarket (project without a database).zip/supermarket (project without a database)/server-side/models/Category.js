var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');


var categorySchema = new mongoose.Schema({
    cat_id: Number,
    name_category:String
});

var Category = mongoose.model('Category', categorySchema, "category");
module.exports = Category;
