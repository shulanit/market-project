var express = require('express');
var mongoose = require('mongoose');


var productCartSchema = new mongoose.Schema({
    //_id: { type: String, require: false},
    id_product:String,
    count:Number,
    price:Number,
    finalPrice:Number,
    cart_id:String,
    productName:String
});

var productCart = mongoose.model('ProductCart', productCartSchema, "productsCart");
module.exports = productCart;
