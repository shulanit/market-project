var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');


var productSchema = new mongoose.Schema({
    product_id:Number,
    name_product:String,
    category_id:String,
    price:Number,
    image:String
});

var Product = mongoose.model('Product', productSchema, "products");
module.exports = Product;
