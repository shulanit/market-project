var express = require('express');
var mongoose = require('mongoose');


var shoppingCartSchema = new mongoose.Schema({
    id_cart:Number,
    user_id:Object,
    create_date:Date
});

var shoppingCart = mongoose.model('Cart', shoppingCartSchema, "shoppingCart");

module.exports = shoppingCart;
