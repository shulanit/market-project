var express = require('express');
var router = express.Router();
//var passport = require('passport');
var ProductModel = require('../models/Product');

/* GET product page. */

router.post('/add', function (req, res, next) {
  console.log("add product");

  let p = new ProductModel();
  p.name_product = req.body.name;
  p.category_id = req.body.category;
  p.price = req.body.price;
  p.image = req.body.image;

  console.log(p);

  p.save(function (err) {
    if (err) {
      console.log(err);
      return res.status(500).send(err);
    }

    res.json({ message: "inserted" });
    console.log(res.message);
  });

});
//router.get('/products/:cat',)
router.get('/getproducts', async function (req, res, next) {
  //console.log("get all product");
  try {
    var products = await ProductModel.find();
    res.send(products);
  } catch (err) {
    res.send(err);
  }
});

router.post('/getproducts', async function (req, res, next) {
  let category = req.body.cat;
  console.log(category);

  try {

    var products = await ProductModel.find({ category_id: category });
    res.send(products);


  } catch (err) {
    res.send(err);
  }
  
});

router.get('/product/:id',async function (req, res) {
  console.log(req.params.id);
  const product_id = req.params.id;
  try{
    var product = await ProductModel.findOne({_id:product_id});
    res.send(product);

  } catch (err) {
    res.send(err);
  }
});

router.put('/product/:id', async function (req, res) {
  const p_id = req.params.id;
  const pro = req.body.editedProduct;//the new 

  try {
    const filter = { _id: p_id };
    
    const update = {name_product:pro.nameproduct,category_id:pro.category,image:pro.picture,price:pro.price};

    await ProductModel.findOneAndUpdate(filter,update,{
      new: true,
      useFindAndModify: false,
      upsert: true});
    //console.log(products);
    res.send("Product successfully updated");
    //res.send(products);


  } catch (err) {
    res.send(err);
  }
});


module.exports = router;
