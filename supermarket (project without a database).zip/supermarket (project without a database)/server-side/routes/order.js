var express = require('express');
var router = express.Router();
const Order = require('../models/order');
var fs = require('fs');
var path = require('path');

/* GET order page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/get_orders', async function (req, res) {
  try {
    var orders = await Order.find();
    res.send(orders);
  } catch (err) {
    res.send(err);
  }
})

router.post('/new_order', function (req, res) {
  console.log("new order", req.body);
  Order.find({ date_to_send: req.body.date_to_send }, (err, countOrders) => {//this user id
    if (err) {
      res.status(500).send(err);
    }
    if (countOrders.length >= 3) {
      res.status(200).send({ message: "כל המשלוחים תפוסים לתאריך זה. בחר תאריך אחר למשלוח" })
    }
    else {
      let new_order = new Order(req.body);
      new_order.save((err, response) => {
        if (err) {
          console.log(err)
          res.status(500).send(err);
        } else {
          res.status(200).send({ message: "the order created!", response });
        }
      })

    }
  })
})

router.get('/print/:_id', function (req, res) {
  let id = req.params._id;
  console.log(id);

  Order.findOne({ _id: id }, (err, myOrder) => {
    if (err) {
      console.log(err);
      res.status(500).send(err);
    }
    let listItems = "";
    for (let i = 0; i < myOrder.list.length; i++) {
      listItems += " שם: " + myOrder.list[i].name + " כמות: " + myOrder.list[i].count + " מחיר: " + myOrder.list[i].finalPrice + "\r\n";
      console.log(myOrder.list[i]);
    }
    console.log(listItems);
    let date = `${myOrder.date_order.getDate()} / ${myOrder.date_order.getMonth()} / ${myOrder.date_order.getFullYear()} `;
    let d_send = `${myOrder.date_to_send.getDate()} / ${myOrder.date_to_send.getMonth()} / ${myOrder.date_to_send.getFullYear()} `
    let orderDetails = `תכולת עגלה: \r\n ${listItems}\r\n פרטי משלוח: \r\n 
    עיר: ${myOrder.order_to_city} \r\n כתובת: ${myOrder.order_to_street} \r\n
     תאריך הזמנה: \r\n ${date} \r\n  תאריך משלוח: \r\n ${d_send} \r\n
      מחיר סופי:\r\n ${myOrder.final_price} \r\n מס' כרטיס: \r\n ---${myOrder.card} `;
    fs.writeFileSync(__dirname+"/myOrder.txt", orderDetails);
    res.status(200).send({ message: "file created" });
  })

})

router.post('/download-file', function (req, res) {
  let filepath = path.join(__dirname) + '/' + req.body.filename;
  res.sendFile(filepath);
});

module.exports = router;