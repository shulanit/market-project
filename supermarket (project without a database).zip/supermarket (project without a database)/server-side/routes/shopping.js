var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var jwt = require('jsonwebtoken');
var Account = require('../models/User');
var Cart = require('../models/shopping_cart');
var Order = require('../models/order');
var Product_cart = require('../models/product_cart');
var product = require('../models/Product');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));

/* GET shopping listing. */
function verifyToken(req, res, next) {
    if (!req.headers.authorization) {
        return res.status(401).send('Unauthorized request')
    }
    let token = req.headers.authorization.split(' ')[1];

    if (token === 'null') {
        return res.status(401).send('Unauthorized request')
    }

    let payload = jwt.verify(token, 'secretKey')

    if (!payload) {
        return res.status(401).send('Unauthorized request')
    }
    req.user_id = payload.subject;
    next()
}

router.get('/create-cart', verifyToken, function (req, res) {
    const user = { user_id: req.user_id , create_date: new Date()};
    
    const cart = new Cart(user);
    cart.save((err, cart_info) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        res.status(200).send({ cart_info })
    })
})

router.post('/push_item', function (req, res) {
    let product_cart = req.body;
    //console.log(product_cart);
    let newProduct_cart = new Product_cart(product_cart);

    newProduct_cart.save((err, product_cart) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        res.status(200).send({ product_cart, message: "product added" });
    })
})

router.delete('/removeItem/:_id', function (req, res) {
    let item = req.params._id;
    console.log(item);

    Product_cart.deleteOne({ _id: item }, (err, message) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        res.status(200).send({ message: "item deleted" })
    })
})

router.delete('/deleteAll/:_id', function (req, res) {
    let item = req.params._id;
    console.log(item);

    Product_cart.deleteMany({ cart_id: item }, (err, message) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        res.status(200).send({ message: "items deleted" })
    })
})

router.get('/create-product-cart', function (req, res) {
    //const user = {cart_id: req.user_id};
    const cart = new Cart(cart_id);
    cart.save((err, cart_info) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        res.status(200).send({ cart_info })
    })
})


router.get('/get_status_cart', verifyToken, function (req, res) {
    const user = req.user_id;
    Cart.find({ user_id: user }, (err, carts) => {//this user id
        if (err) {
            res.status(500).send(err);
        }
        if (carts == 0) {
            let value = "no cart";
            res.send({ value });//first time shopping
        }//this is carts
        else {
            const lastcartOrder = carts[carts.length - 1];//last cart
            console.log(lastcartOrder);
            Order.find({ cart_id: lastcartOrder._id }, (err, order) => {
                if (err) {
                    res.status(500).send(err);
                }
                if (order == 0) {
                    let value = "cart open";//still shopping
                    res.send({ carts: lastcartOrder, value: value })
                }
                else {
                    let value = "cart close";//finish need to create cart
                    res.send({ order, value });
                }
            })//this is orders
        }
    })
})

router.post('/create-order', function (req, res) {
    let order = new Order(req.body);
    order.save((err, order_info) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        res.status(200).send({ order_info });
    })
})

router.get('/get_cart/:cartID', function (req, res) {
    const cartID = req.params.cartID;

    Product_cart.find({ cart_id: cartID }, (err, data) => {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }

        res.status(200).send(data)
    })
})


module.exports = router;