var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var passport = require('passport');
var Account = require('../models/User');
//mongoose.connect('mongodb://localhost:27017/myMarket', {useNewUrlParser: true});
var db = mongoose.connection;
const jwt = require("jsonwebtoken");
db.on('error', console.error.bind(console, 'connection error:'));

/* GET registration listing. */

router.post('/check_register', (req, res) => {
  let userData = req.body
  db.collection("users").find({user_id:userData.user_id}).toArray(function(err, result) {
    console.log(result);
    if (err) throw err;
    else if(result.length>0){
      res.json({message:"user exist"});
      console.log("user exist");
    } 
    else{
      console.log("continue");
      res.json({message:"continue"});
    }
  });
  
})

router.post('/reg', function(req,res,next){
  console.log(req.body);
  var user = {
    user_id: req.body.user_id,
    email: req.body.email,
    username: req.body.username,
    password: req.body.password,
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    city: req.body.city,
    address: req.body.address,
    role:2
  };  
  console.log(user);

    let User = new Account(user)
    User.save((err, responseUser) => {
        if (err) {
            console.log(err)
        } else {
            let payload = { subject: responseUser._id };
            let token = jwt.sign(payload, "secretKey");
            res.status(200).send([{ token }, {message:"registeration success"}])
        }
    })

})
module.exports = router;
