var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var User = require('../models/User');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
const jwt = require("jsonwebtoken");
//const verifyToken = require('./shopping');


/* GET login listing. */
function verifyToken(req, res, next) {
  if (!req.headers.authorization) {
      return res.status(401).send('Unauthorized request')
  }
  let token = req.headers.authorization.split(' ')[1];

  if (token === 'null') {
      return res.status(401).send('Unauthorized request')
  }

  let payload = jwt.verify(token, 'secretKey')

  if (!payload) {
      return res.status(401).send('Unauthorized request')
  }
  req.user_id = payload.subject;
  next()
}

router.post('/login', function (req, res) {
  let username = req.body.username;
  let password = req.body.password;

  User.findOne({ username: username }, (err, user) => {
    if (err) {
      console.log(err)
    } else {
      if (!user) {
        res.status(401).send('Invalid Username');
      } else
        if (user.password !== password) {
          res.status(401).send('Invalid Password')
        } else {
          let payload = { subject: user._id };
          let token = jwt.sign(payload, "secretKey");
          res.status(200).send({ token: token, message:"login success", role:user.role })

        }
    }
   
  });
});


router.get('/logout', function (req, res) {
  req.logout();
  res.json({ message: "logout success" });
});

router.get('/getUser', verifyToken, function (req, res){
  const userId = req.user_id;
  console.log(userId);
  User.findOne({ _id: userId }, (err, user) => {
    if (err) {
      console.log(err)
    } else {
      if (!user) {
        res.send("user not found");
      } else if(user){
        console.log(user.username);
        let username = user.username;
        res.json({data:username});
      }
    }
  
  });
  
})

router.get('/getFullUser', verifyToken, function (req, res){
  const userId = req.user_id;
  console.log(userId);
  User.findOne({ _id: userId }, (err, user) => {
    if (err) {
      console.log(err)
    } else {
      if (!user) {
        res.send("user not found");
      } else if(user){
        console.log(user);
        // let username = user.username;
        res.json({data:user});
      }
    }
  
  });
  
})

module.exports = router;
