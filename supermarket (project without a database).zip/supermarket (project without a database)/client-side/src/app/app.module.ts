import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { MatButtonModule, MatCheckboxModule, MatSidenavModule, MatMenuModule } from '@angular/material';
import { AppComponent } from './app.component';
import { HeadPageComponent } from './components/head-page/head-page.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { AppRoutingModule } from './app-routing.module';
import { ShoppingComponent } from './components/shopping/shopping.component';
import { ParentComponent } from './parent/parent.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdminComponent } from './components/admin/admin.component';
import { SidebarModule } from 'ng-sidebar';
import { FilterListPipe } from './filter-list.pipe';

import { OrderComponent } from './components/order/order.component';
import { JwtService } from './services/jwt.service';
import { InvoicingComponent } from './components/invoicing/invoicing.component';


@NgModule({
  declarations: [
    AppComponent,
    HeadPageComponent,
    LoginComponent,
    RegistrationComponent,
    ShoppingComponent,
    ParentComponent,
    AdminComponent,
    FilterListPipe,
    OrderComponent,
    InvoicingComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatMenuModule,
    MatCheckboxModule,
    MatSidenavModule,
    SidebarModule.forRoot()
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: JwtService,
    multi: true
  },
    ShoppingComponent,
    ],
  exports: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
