import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
//import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { ParentComponent } from '../app/parent/parent.component';
import { ShoppingComponent } from './components/shopping/shopping.component';
import { AdminComponent } from './components/admin/admin.component';
import { OrderComponent } from './components/order/order.component';
import { LoginGuardGuard } from './services/login-guard.guard';
import { InvoicingComponent } from './components/invoicing/invoicing.component';


const routes: Routes = [
  { path: 'login', component: ParentComponent },
  { path: '', component: ParentComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'shopping', component: ShoppingComponent, canActivate: [LoginGuardGuard] },
  { path: 'order', component: OrderComponent, canActivate: [LoginGuardGuard] },
  { path: 'admin', component: AdminComponent, canActivate: [LoginGuardGuard] },
  { path: "invoicing", component: InvoicingComponent}
];

@NgModule({
  declarations: [  
  ],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ]
  //exports: [RouterModule]
})
export class AppRoutingModule { }
