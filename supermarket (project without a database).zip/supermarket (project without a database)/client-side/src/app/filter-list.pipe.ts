import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterList'
})
export class FilterListPipe implements PipeTransform {
  data_products = [];
  transform(items: any[], filter_text: string): any {
    if (filter_text != "") {
      this.data_products = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].name_product.indexOf(filter_text) !== -1) {
          //console.log(items[i]._id);
          this.data_products.push({name:items[i].name_product,id:items[i]._id});
        }
      }
      return this.data_products;
    }
   
  }

}
