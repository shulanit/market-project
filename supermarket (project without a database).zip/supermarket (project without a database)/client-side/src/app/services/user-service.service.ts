import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  username: string = 'guest';
  constructor(private http: HttpClient) { }

  login(username, password) {
    this.username = username;
    return this.http.post("http://localhost:3010/login/login", { username: username, password: password });
  }

  public loggedIn() {
    return !!localStorage.getItem("token");//check if token true or false
  }


  logout() {
    this.username = 'guest';
    return this.http.get("http://localhost:3010/login/logout");
  }

  public getToken() {
    return localStorage.getItem("token");
  }

  getUser(){
    return this.http.get("http://localhost:3010/login/getUser");
  }

  getFullUser(){
    return this.http.get("http://localhost:3010/login/getFullUser");
  }
}
