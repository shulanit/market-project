import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
//import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(public http: HttpClient) { }

  oredr(myOrder) {
    return this.http.post("http://localhost:3010/order/new_order", myOrder);
  }

  print(id) {
    return this.http.get(`http://localhost:3010/order/print/${id}`);
  }

  downloadFile(file: String) {
    var body = { filename: file };//only name file

    return this.http.post('http://localhost:3010/order/download-file', body, {
      responseType: 'blob',
      headers: new HttpHeaders().append('Content-Type', 'application/json')
    });
  }
}
