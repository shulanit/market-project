import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor } from "@angular/common/http";
import { UserServiceService } from './user-service.service';

@Injectable({
  providedIn: 'root'
})
export class JwtService implements HttpInterceptor {

  constructor(private injector: Injector) { }

  public intercept(req, next) {
    let userServiceService = this.injector.get(UserServiceService)
    let tokenizedReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${userServiceService.getToken()}`
      }
    })
    return next.handle(tokenizedReq)
  }
}
