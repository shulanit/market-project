import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  category:Number;
  constructor(private http: HttpClient) { }

  show_p(cat){
    return this.http.post("http://localhost:3010/product/getproducts",{cat:cat});
  }

  getAllProduct(){
    return this.http.get("http://localhost:3010/product/getproducts");
  }

  getAllorders(){
    return this.http.get("http://localhost:3010/order/get_orders");
  }

  addP(name,category,price,image){
    if(category == "milk & eggs"){
      category = 1;
    }
    else if(category == "vegetables & fruits"){
      category = 2;
    }
    else if(category == "meat & fish"){
      category = 3;
    }
    else if(category == "wine & drinks"){
      category = 4;
    }
    return this.http.post("http://localhost:3010/product/add",{name:name,category:category,price:price,image:image});
  }

  showToUpdate(id_p){
    console.log("this is show to update",id_p);

  }

  update(editedProduct,p_id){
    return this.http.put(`http://localhost:3010/product/product/${p_id}`,{editedProduct});
  }

  getItem(id){
    return this.http.get(`http://localhost:3010/product/product/${id}`);
  }

}
