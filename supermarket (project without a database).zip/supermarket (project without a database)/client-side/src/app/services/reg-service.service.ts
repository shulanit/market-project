import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegServiceService {

  constructor(private http: HttpClient) { }


  registerStepA(user_id,email,username,password){
    return this.http.post("http://localhost:3010/registration/check_register",{user_id:user_id,email:email,username:username,password:password});
  }

  register(user_id,email,username,password,firstName,lastName,city,address){
    return this.http.post("http://localhost:3010/registration/reg",{user_id:user_id,email:email,username:username,password:password,firstName:firstName,lastName:lastName,city:city,address:address});
  }
}
