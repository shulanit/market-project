import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ShoppingService {
  listShopping = [];
  constructor(public httpClient:HttpClient ) { }

  order(listShopping) {
    this.listShopping = listShopping;
  }

  public getCartStatus() {
    return this.httpClient.get("http://localhost:3010/shopping/get_status_cart");
  }

  public createCart() {
    return this.httpClient.get("http://localhost:3010/shopping/create-cart");
  }

  pushProduct(item){
    return this.httpClient.post("http://localhost:3010/shopping/push_item",item);
  }

  removeProduct(item){
    return this.httpClient.delete("http://localhost:3010/shopping/removeItem/"+item);
  }

  getCart(cartID){
    return this.httpClient.get(`http://localhost:3010/shopping/get_cart/${cartID}`);
  }

  deleteAll(cart_id){
    return this.httpClient.delete(`http://localhost:3010/shopping/deleteAll/${cart_id}`)
  }
}
