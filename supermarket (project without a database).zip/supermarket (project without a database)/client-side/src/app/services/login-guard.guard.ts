import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UserServiceService } from './user-service.service';

@Injectable({
  providedIn: 'root'
})
export class LoginGuardGuard implements CanActivate {
  public constructor(private userService: UserServiceService, private router: Router) { }

  public canActivate(): boolean {
    if (this.userService.loggedIn() == true) {
      return true;
    }
    else {
      this.router.navigate(["/login"]);
      return false;
    }
    
  }
}
