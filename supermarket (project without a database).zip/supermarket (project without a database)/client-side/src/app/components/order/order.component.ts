import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
//import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { ShoppingService } from '../../services/shopping.service';
import { UserServiceService } from '../../services/user-service.service';
import { OrderService } from '../../services/order.service';
import { ShoppingComponent } from '../shopping/shopping.component';
//import { InvoicingComponent } from '../invoicing/invoicing.component';
import { HeadPageComponent } from '../head-page/head-page.component';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  providers: [ShoppingComponent, HeadPageComponent]
})
export class OrderComponent implements OnInit {
  listShopping = [];
  allProducts = [];
  Sum: Number = 0;
  search_field = "";
  values: any;
  user_information: any;
  city: String;
  address: String;
  creditCard:String;
  myId:String;
  constructor(private router: Router,
    private shopping: ShoppingService,
    private user: UserServiceService,
    private orderService: OrderService,
    private product: ProductService,
    private shoppingComp: ShoppingComponent,
    private headComponent: HeadPageComponent) { }

  ngOnInit() {
    this.headComponent.setData();
    this.getProducts();
    this.getUser();
    this.getDataOnList();
  }

  getDataOnList(){
    let cart_id = localStorage.getItem("cartID");
    this.shopping.getCart(cart_id)
      .subscribe((res: any) => {
        //console.log("continueShopping with id", res);
        for (var i = 0; i < res.length; i++) {
          for (var j = 0; j < this.allProducts.length; j++) {
            if (res[i].id_product === this.allProducts[j]._id) {
              res[i].name = this.allProducts[j].name_product;
            }
          }
        }
        this.listShopping = res;
      
      if(this.listShopping.length>0){
        this.sumTotal();
      }
    })
  }

  getProducts() {
    this.product.getAllProduct()
      .subscribe(
        (res: any) => {
          this.allProducts = res;
        },
        (err) => {
          console.log("Error", err);
        }
      );
  }

  back() {
    this.router.navigate(['/shopping']);
    this.shoppingComp.continueShopping()
  }

  sumTotal() {
    for (var i = 0; i < this.listShopping.length; i++) {
      this.Sum += this.listShopping[i].finalPrice;
    }
  
  }

  getUser() {
    this.user.getFullUser()
      .subscribe(
        (res: any) => {
          if (res.data !== null && res.data !== undefined) {
            this.user_information = res.data;
          }
          else {
            alert("username is" + res.data);
          }
        },
        (err) => {
          console.log("Error", err);

        }
      );

  }

  create_order(value, toSend, toOrder) {
    this.getFourdigit(value);
    if (!this.checkCreditCard(value)) { 
      //console.log("the card not ok");
      return;
    }
    //console.log("the card is ok")
    var myList = [];
    for (var i = 0; i < this.listShopping.length; i++) {
      myList.push({
        name: this.listShopping[i].name,
        count: this.listShopping[i].count,
        finalPrice: this.listShopping[i].finalPrice
      })
    }
  
    var myOrder: any = {
      list: myList,
      user_id: this.user_information._id,//מזהה לקוח
      cart_id: this.listShopping[0].cart_id,//מזהה עגלה
      order_to_city: this.city,
      order_to_street: this.address,
      date_order:toOrder,
      date_to_send: toSend,
      final_price: this.Sum,
      card: this.creditCard
    }
    //console.log(myOrder);
    this.order(myOrder);
  }

  order(myOrder){
    this.orderService.oredr(myOrder)
    .subscribe((res:any) => {
      if(res){
        if(res.message == "the order created!"){
          localStorage.setItem('idorder',res.response._id);
            this.router.navigate(['/invoicing']);
        }
        else{
          alert(res.message);
        }
      }
      (err) => {
        console.log("Error", err);
      }
    })
  }

  getFourdigit(value) {//last four numbers of card
    let myMunber = [];
    for (var i = 12; i < 16; i++) {
      let num = value[i]*1
      myMunber.push(num);
    }
    //console.log(myMunber, myMunber.join(''));
    this.creditCard = myMunber.join('');
  }

  checkCreditCard(value) {

    const reg = /^[0-9]*$/;

    if (!value.match(reg)) {
      return false;
    }
    // currently our users can use only visa or mastercard, with 16 digits
    if (!(value.length == 16)) {
      return false;
    }

    return true;
  }


  dataUser(myInput) {
    if (myInput == "InputCity") {
      this.city = this.user_information.city;

    }
    else if (myInput == "InputAddress") {
      this.address = this.user_information.address;
    }
  }
}
