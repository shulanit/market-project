import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/services/order.service';
import { Router } from '@angular/router';
import {saveAs} from 'file-saver';


@Component({
  selector: 'app-invoicing',
  templateUrl: './invoicing.component.html',
  styleUrls: ['./invoicing.component.css']
})
export class InvoicingComponent implements OnInit {
  myId: String;
  constructor(private orderService: OrderService, private router: Router) { }

  ngOnInit() {
  }

  print() {
    this.myId = localStorage.getItem('idorder');
    this.orderService.print(this.myId)
      .subscribe((res: any) => {
        var filename = "myOrder.txt";
        this.orderService.downloadFile(filename)
        .subscribe(
          data => saveAs(data, filename),
          error => console.error(error)
        );
      }),
      (err) => {
        console.log("Error", err);
      } 
  }

  toLogin(){
    this.router.navigate(['/login']);
  }


}
