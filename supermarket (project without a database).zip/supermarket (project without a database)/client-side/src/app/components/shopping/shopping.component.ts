import { Component, OnInit, Input } from '@angular/core';
import { UserServiceService } from '../../services/user-service.service';
import { Router } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { ShoppingService } from '../../services/shopping.service';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css']
})
export class ShoppingComponent implements OnInit {
  listShopping = [];//add all product user adding
  search: string = '';
  opened: boolean;
  events: string[] = [];
  info = [];
  search_field: String;
  values: any;
  allProducts = [];
  private _opened: boolean = true;
  private show: boolean = false;
  private createC: boolean = false;
  private continue: boolean = false;
  disableTextbox = false;
  Count: Number;
  ProductArr = [];
  data_cart:String;
  last_date:Date;


  constructor(private userservice: UserServiceService,
    private router: Router,
    private product: ProductService,
    private shopping: ShoppingService) { }

  ngOnInit() {
    this.getProducts();
    this.cartStatus();
  }

  getProducts() {
    this.product.getAllProduct()
      .subscribe(
        (res: any) => {
          this.allProducts = res;
        },
        (err) => {
          console.log("Error", err);

        }
      );
  }

  private _toggleSidebar() {
    this._opened = !this._opened;
  }

  toggleDisable() {
    this.disableTextbox = !this.disableTextbox;
  }

  showList() {
    this._toggleSidebar();
  }

  logout() {
    localStorage.removeItem("token");
    this.userservice.logout()
      .subscribe(
        (res: any) => {
          if (res.message == "logout success") {
            this.router.navigate(['/']);
          }
        },
        (err) => {
          console.log("Error", err);
        }
      );
  }

  showProducts(cat) {
    this.product.show_p(cat)
      .subscribe(
        (res: any) => {
          this.info = res;
          for (var i = 0; i < this.info.length; i++) {
            if (this.info[i].category_id == 1) {
              this.info[i].category_id = "milk & eggs"
            }
            else if (this.info[i].category_id == 2) {
              this.info[i].category_id = "vegetables & fruits"
            }
            else if (this.info[i].category_id == 3) {
              this.info[i].category_id = "meat & fish"
            }
            else if (this.info[i].category_id == 4) {
              this.info[i].category_id = "wine & drinks"
            }
          }
        },
        (err) => {
          console.log("Error", err);

        }
      )
  }

  getItem(id) {
    this.product.getItem(id)
      .subscribe(
        (res: any) => {
          this.info = [];
          this.info = [res];
          if (this.info[0].category_id == 1) {
            this.info[0].category_id = "milk & eggs"
          }
          else if (this.info[0].category_id == 2) {
            this.info[0].category_id = "vegetables & fruits"
          }
          else if (this.info[0].category_id == 3) {
            this.info[0].category_id = "meat & fish"
          }
          else if (this.info[0].category_id == 4) {
            this.info[0].category_id = "wine & drinks"
          }
          this.search_field = "";
        },
        (err) => {
          console.log("Error", err);

        }
      )
  }

  search_product(event) {
    this.values += event.target.value;
  }

  choose_p(pro) {
    this.getItem(pro.id);
  }

  deleteProducts() {
    this.listShopping = [];
    this.shopping.deleteAll(localStorage.getItem("cartID"))
    .subscribe((res) => {
    })
    this.show = false;
  }

  showProductModal(product) {
    this.ProductArr = product;
  }

  addToMyList(name, id, price, count) {
    let finalPrice: Number = price * count;
    let cart_id = localStorage.getItem("cartID");
    var Item: any = {
      name: name,
      id_product: id,
      count: count,
      price: price,
      finalPrice,
      cart_id: cart_id
    }
    if (this.show == false) {
      this.show = !this.show;
    }
    
    this.shopping.pushProduct(Item)
      .subscribe((res: any) => {
        Item._id = res.product_cart._id
        this.listShopping.push(Item);
      })
    this.sumTotal();
  }

  deleteProduct(p) {
    this.shopping.removeProduct(p._id)
      .subscribe((res: any) => {
        if (res) {
        }
        (err) => {
          console.log("Error", err);

        }
      });

    for (var i = 0; i < this.listShopping.length; i++) {
      if (this.listShopping[i]._id == p._id) {
        this.listShopping.splice(i, 1);
        //console.log(this.listShopping);
        if (this.listShopping.length == 0) {
          this.show = false;
        }
      }
    }
    this.sumTotal();
  }

  continueShopping() {
    this.continue = !this.continue;
    this.show = true;
    let cart_id = localStorage.getItem("cartID");
    this.shopping.getCart(cart_id)
      .subscribe((res: any) => {
        //console.log("continueShopping with id", res);
        for (var i = 0; i < res.length; i++) {
          for (var j = 0; j < this.allProducts.length; j++) {
            if (res[i].id_product === this.allProducts[j]._id) {
              res[i].name = this.allProducts[j].name_product;
            }
          }
        }
        this.listShopping = res;
      
      if(this.listShopping.length>0){
        this.sumTotal();
      }
    })
  }

  ToOrder(listShopping) {
    this.shopping.order(listShopping);
    this.router.navigate(['/order']);
  }

  cartStatus() {
    this.shopping.getCartStatus()
      .subscribe((res: any) => {
        if (res.value === "no cart") {
          this.createC = !this.createC;//change to true
        }
        if (res.value == "cart open") {
          this.createC = false;
          localStorage.setItem("cartID", res.carts._id);
          sessionStorage.setItem("cartDateCreated", res.carts.create_date);
          this.continue = !this.continue;
          this.continueShopping();
        }
        if (res.value == "cart close") {
          this.createC = true;
          sessionStorage.setItem("cartLastOrderDate", res.order[0].date_order);
        }
        err => console.log("error: ", err)
      })
  }

  createCart() {
    this.shopping.createCart()//need onclick to create cart
      .subscribe((cart: any) => {
        //console.log("res2", cart)
        localStorage.setItem("cartID", cart.cart_info._id);
      },
        err => console.log("error: ", err))
    this.createC = false;
  }

  sumTotal() {
    let sum = 0;
    for (var i = 0; i < this.listShopping.length; i++) {
      sum += this.listShopping[i].finalPrice;
    }
    return sum;
  }
}

