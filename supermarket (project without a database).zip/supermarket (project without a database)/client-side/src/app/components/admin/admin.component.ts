import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { UserServiceService } from '../../services/user-service.service';
import { IProduct } from 'src/models/Product';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  nameproduct: String = '';
  category: String = '';
  price: Number = 0;
  picture: String;
  info = [];
  allProducts = [];
  show = false;
  edited_id: String = '';
  values: any;
  search_field: String;
  private _opened: boolean = false;

  constructor(private Product_management: ProductService,private router: Router, private userservice:UserServiceService) { }

  ngOnInit() {
    this.getProducts();
  }

  private _toggleSidebar() {
    this._opened = !this._opened;
  }

  getProducts() {
    this.Product_management.getAllProduct()
      .subscribe(
        (res: any) => {
          this.allProducts = res;
        },
        (err) => {
          console.log("Error", err);

        }
      );
  }

  getItem(id) {
    this.Product_management.getItem(id)
      .subscribe(
        (res: any) => {
          this.info = [];
          this.info = [res];
          if (this.info[0].category_id == 1) {
            this.info[0].category_id = "milk & eggs"
          }
          else if (this.info[0].category_id == 2) {
            this.info[0].category_id = "vegetables & fruits"
          }
          else if (this.info[0].category_id == 3) {
            this.info[0].category_id = "meat & fish"
          }
          else if (this.info[0].category_id == 4) {
            this.info[0].category_id = "wine & drinks"
          }
          this.search_field = "";
        },
        (err) => {
          console.log("Error", err);
        }
      )
  }

  showProducts(cat) {
    this.Product_management.show_p(cat)
      .subscribe(
        (res: any) => {
          this.info = res;
          for (var i = 0; i < this.info.length; i++) {
            if (this.info[i].category_id == 1) {
              this.info[i].category_id = "milk & eggs"
            }
            else if (this.info[i].category_id == 2) {
              this.info[i].category_id = "vegetables & fruits"
            }
            else if (this.info[i].category_id == 3) {
              this.info[i].category_id = "meat & fish"
            }
            else if (this.info[i].category_id == 4) {
              this.info[i].category_id = "wine & drinks"
            }
          }
        },
        (err) => {
          console.log("Error", err);

        }
      )
  }

  showForm() {
    this._toggleSidebar();
  }

  clearForm() {
    this.showForm();
    this.nameproduct = '';
    this.category = '';
    this.price = 0;
    this.picture = '';
  }

  cancel(){
    this.clearForm();
  }
  
  add() {
    this.Product_management.addP(this.nameproduct, this.category, this.price, this.picture)
      .subscribe(
        (res: any) => {
          if (res.message == "inserted") {
            //console.log("product inserted success");
            this.clearForm();
          }
        },
        (err) => {
          console.log("Error", err);
        }
      );
  }

  choose(p) {
    this.fillEditForm(p);
    this.showForm();
  }

  fillEditForm(p: IProduct) {
    this.edited_id = p._id;
    this.nameproduct = p.name_product;
    this.price = p.price;
    this.category = p.category_id;
    this.picture = p.image;
  }

  update() {
    const editedProduct = {
      price: this.price,
      nameproduct: this.nameproduct,
      picture: this.picture,
      category: this.category
    }

    this.Product_management.update(editedProduct, this.edited_id).
      subscribe(
        (res: any) => {
          console.log(res,"the product updated");
        },
        (err) => {
          console.log("Error", err);
        }
      );
    this.clearForm();
  }

  search_product(event) {
    this.values += event.target.value;
  }

  choose_p(pro) {
    this.getItem(pro.id);
  }

  logout() {
    localStorage.removeItem("token");
    this.userservice.logout()
      .subscribe(
        (res: any) => {
          if (res.message == "logout success") {
            this.router.navigate(['/']);
          }
        },
        (err) => {
          console.log("Error", err);
        }
      );
  }

}
