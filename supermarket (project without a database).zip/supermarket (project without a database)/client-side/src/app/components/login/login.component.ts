import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../../services/user-service.service';
import { Router } from '@angular/router';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
username:string = '';
password:string = '';
count_products:Number;
count_orders:Number;
  constructor(private login_user:UserServiceService, 
              private router:Router,
              private products:ProductService) { }

  ngOnInit() {
    this.CountProducts();
    this.CountOrders();
    this.checkUserStatus();
  }

  login(){
    this.login_user.login(this.username,this.password)
    .subscribe(
      (res:any)=>{
        if(res.message == "login success"){
          localStorage.setItem("token", res.token);
          localStorage.setItem("role",res.role);
          if(res.role == 1){
            this.router.navigate(['/admin']);
          }
          else{
          this.router.navigate(['/shopping']);
          }
        }
      },
      (err)=>{
        console.log( "Error" , err);
        if(err.status != 200 ){
          //console.log("user not found");
          alert("user not found");
        }

      }
    );

  }

  checkUserStatus(){
    if(localStorage.token){
      if(localStorage.role == 1){
        this.router.navigate(['/parent']);
      }
      else{
        this.router.navigate(['/shopping']);
      }
    }
  }

  CountProducts(){
    this.products.getAllProduct()
    .subscribe(
      (res:any)=>{
        this.count_products = res.length;
      },
      (err)=>{
        console.log( "Error" , err);
      }
    )
  }

  CountOrders(){
    this.products.getAllorders()
    .subscribe(
      (res:any)=>{
        this.count_orders = res.length;
      },
      (err)=>{
        console.log( "Error" , err);
      }
    )
  }
    
}
