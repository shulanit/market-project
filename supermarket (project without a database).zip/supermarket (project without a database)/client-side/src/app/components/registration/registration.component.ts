import { Component, OnInit } from '@angular/core';
import { RegServiceService } from '../../services/reg-service.service';
import { Router } from '@angular/router';
//import { from } from 'rxjs';
//import { registerLocaleData } from '@angular/common';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  ID: string = '';
  Email: string = '';
  username: string = '';
  pass: string = "";
  pass_con: string = "";
  firstName: string = '';
  lastName: string = '';
  city: string = '';
  address: string = '';
  show = false;
  hide = true;
  constructor(private registration: RegServiceService, private router: Router) { }

  ngOnInit() {
  }

  checkReg() {
    if (this.pass === this.pass_con) {
      if (this.pass != this.pass_con) {
        alert("Passwords do not match");
        return;
      }
      this.registration.registerStepA(this.ID, this.Email, this.username, this.pass)
        .subscribe(
          (res: any) => {
            if (res.message == "continue") {
              this.show = !this.show;
              this.hide = !this.hide;
            }
            else if (res.message == "user exist") {
              //console.log(res.message);//need to show message to user! 
              alert("user exist");
            }
          },
          (err) => {
            console.log("Error", err);
          }
        );

    }
    else {
      //console.log("One of the details is incorrect");
      alert("One of the details is incorrect");
    }
  }

  register() {
    this.registration.register(this.ID, this.Email, this.username, this.pass, this.firstName, this.lastName, this.city, this.address)
      .subscribe(
        (res: any) => {
          //console.log(res[1].message);
          if (res[1].message == "registeration success") {
            localStorage.setItem("token", res[0].token);
            this.router.navigate(['/shopping']);
          }
        },
        (err) => {
          console.log("Error", err);
        }
      );
  }
}



