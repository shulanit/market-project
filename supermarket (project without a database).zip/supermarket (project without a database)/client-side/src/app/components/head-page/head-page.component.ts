import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserServiceService } from 'src/app/services/user-service.service';
import { ShoppingService } from 'src/app/services/shopping.service';


@Component({
  selector: 'app-head-page',
  templateUrl: './head-page.component.html',
  styleUrls: ['./head-page.component.css']
})
export class HeadPageComponent implements OnInit {

  username = 'guest';
  cartDateCreated;
  textDataOnShopping: string;
  constructor(private http: HttpClient,
              private loginServise: UserServiceService,
              private shopping: ShoppingService) { }
          
  ngOnInit() {
    this.getUsername();
    setTimeout(()=>{
      if(this.username !== "admin"){
        this.shopping.getCartStatus()
          .subscribe((res: any) => {
            if (res.value === "no cart") {
              this.textDataOnShopping = " ברוך הבא לקנייה הראשונה שלך"
            }
            if (res.value == "cart open") {
              this.textDataOnShopping = "יש לך עגלה פתוחה מתאריך";
              this.cartDateCreated = sessionStorage.getItem("cartDateCreated");
            }
            if (res.value == "cart close") {
              this.textDataOnShopping = " רכישה אחרונה בתאריך";
              this.cartDateCreated = sessionStorage.getItem("cartLastOrderDate");
            }
          })
        }
    },1000)
    
  }

  getUsername() {
    this.loginServise.getUser()
      .subscribe(
        (res: any) => {
          if (res.data !== null && res.data !== undefined) {
            this.username = res.data;
          }
          else {
            alert("username is" + res.data);
          }
        },
        (err) => {
          console.log("Error", err);
        }
      );
  }

  setData() {
    this.changeStyle();
  }

  changeStyle(){
    setTimeout(()=>{
      document.querySelector("#data_cart").setAttribute("style","display:none;")
    },500) 
  }
}
