export interface IProduct{
    _id:String,
    name_product:String,
    category_id:String,
    price:Number,
    image:String 
}
